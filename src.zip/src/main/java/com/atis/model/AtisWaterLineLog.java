package com.atis.model;

import net.csdn.jpa.model.Model;

/**
 * Created by Administrator on 2016/11/9.
 */
public class AtisWaterLineLog extends Model{

}
