package com.atis.model;

import net.csdn.jpa.model.Model;

/**
 * Created by Administrator on 2016/11/8.
 */
public class AtisWaterLine extends Model {
}
