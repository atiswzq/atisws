package com.atis.model;

import net.csdn.jpa.model.Model;

/**
 * Created by xshd000 on 2017/2/19.
 */
public class AtisRiver20170218 extends Model{
}
