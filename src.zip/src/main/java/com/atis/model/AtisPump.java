package com.atis.model;

import net.csdn.jpa.model.Model;

/**
 * Created by Administrator on 2016/11/11.
 */
public class AtisPump extends Model{
}
