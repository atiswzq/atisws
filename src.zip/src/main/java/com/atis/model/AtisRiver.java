package com.atis.model;

import net.csdn.common.exception.AutoGeneration;
import net.csdn.jpa.association.Association;
import net.csdn.jpa.model.Model;

import javax.persistence.OneToOne;

/**
 * Created by Administrator on 2016/11/8.
 */
public class AtisRiver extends Model{

}
