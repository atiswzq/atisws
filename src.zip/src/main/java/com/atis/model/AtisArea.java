package com.atis.model;
import net.csdn.jpa.model.Model;

/**
 * Created by xshd000 on 2017/2/19.
 */
public class AtisArea extends Model{
}
