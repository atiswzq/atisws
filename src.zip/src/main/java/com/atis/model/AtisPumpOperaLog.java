package com.atis.model;

import net.csdn.jpa.model.Model;

/**
 * Created by xshd000 on 2017/3/6.
 */
public class AtisPumpOperaLog extends Model {
}
