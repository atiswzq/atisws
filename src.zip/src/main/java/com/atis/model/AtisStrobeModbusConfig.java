package com.atis.model;

import net.csdn.common.collections.WowCollections;
import net.csdn.jpa.model.Model;

import static net.csdn.filter.FilterHelper.BeforeFilter.only;

/**
 * Created by kevin on 2016/11/15.
 */
public class AtisStrobeModbusConfig extends Model{

}
