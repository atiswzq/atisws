package com.atis.model;

import net.csdn.jpa.model.Model;

/**
 * Created by xshd000 on 2017/3/1.
 */
public class AtisGateWaterCurrentXs extends Model {
}
