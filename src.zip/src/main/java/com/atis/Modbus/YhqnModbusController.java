package com.atis.Modbus;

import com.atis.controller.http.ModbusController;

/**
 * Created by xshd000 on 2016/12/23.
 */
public class YhqnModbusController extends ModbusController{
}
